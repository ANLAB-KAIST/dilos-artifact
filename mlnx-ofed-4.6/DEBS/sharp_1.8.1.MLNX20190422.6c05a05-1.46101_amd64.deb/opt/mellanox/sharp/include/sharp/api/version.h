/**
* Copyright (C) Mellanox Technologies Ltd. 2001-2016.  ALL RIGHTS RESERVED.
*
* See file LICENSE for terms.
*/


#ifndef SHARP_VERSION_H_
#define SHARP_VERSION_H_

#define SHARP_VERNO_MAJOR            1
#define SHARP_VERNO_MINOR            8
#define SHARP_VERNO_REV              "1"
#define SHARP_VERNO_STRING           "1.8"

#define SHARP_MINOR_BIT              (16UL)
#define SHARP_MAJOR_BIT              (24UL)
#define SHARP_API                    ((1L<<SHARP_MAJOR_BIT)|(8L << SHARP_MINOR_BIT))

#define SHARP_VERSION(major, minor)  (((major)<<SHARP_MAJOR_BIT)|((minor)<<SHARP_MINOR_BIT))

#endif
