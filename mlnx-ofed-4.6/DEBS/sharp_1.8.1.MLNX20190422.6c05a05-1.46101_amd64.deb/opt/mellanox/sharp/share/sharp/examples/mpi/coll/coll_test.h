/**
 * Copyright (C) Mellanox Technologies Ltd. 2015-2016.  ALL RIGHTS RESERVED.
 * See file LICENSE for terms.
 */

#if !defined(SHARP_MPI_TEST_H)
#define SHARP_MPI_TEST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <malloc.h>
#include <getopt.h>
#include <inttypes.h>
#include <limits.h>
#include <assert.h>
#include <time.h>


#include "mpi.h"
#include "api/sharp.h"

extern int sharp_world_rank;
extern int max_payload_size;
extern int enable_sharp_coll;
extern int perf_test_iterations;
extern int perf_test_skips;
extern int perf_with_barrier;
extern int nbc_count;

enum test_mode {
	TEST_BASIC,
	TEST_COMPLEX,
	TEST_PERF,
	TEST_ALL
};


struct data_template {
	unsigned int unsigned_int_val;
	int int_val;
	unsigned long unsigned_long_val;
	long long_val;
	float float_val;
	double double_val;
	int int_loc_tag_val;
	int int_min_max_loc_result;
};


struct sharp_conf_t {
	int                 max_groups;
	int                 rank;
	int                 size;
	int                 ib_port;
	char                *hostlist; // comma separated
	char                *jobid;
	char		    *ib_dev_list;
	char                *ib_devname;
	enum test_mode      test_mode;
	int		    run_allreduce;
	int		    run_iallreduce;
	int		    run_barrier;
};
typedef struct sharp_conf_t sharp_conf_t;

/*TODO move it dtype.h */
struct sharp_test_data_types_t {
	char name[64];
	int id;
	MPI_Datatype mpi_id;
	MPI_Datatype mpi_min_max_id;
	int size;
};

struct sharp_op_type_t {
	char name[64];
	int id;
	MPI_Op mpi_op;
};

enum {
	PARSE_ARGS_OK = 0,
	PARSE_ARGS_HELP = 1,
	INVALID_ARG = 2,
	INVALID_MAX_GROUPS = 3,
	INVALID_GROUP_TYPE = 4,
	INVALID_TEST_MODE = 5,
	INVALID_COLL_LIST = 6,
};

/* comm types */
enum {
	COMM_TYPE_WORLD = 0,
	COMM_TYPE_WORLD_DUP = 1,
	COMM_TYPE_WORLD_REVERSE = 2,
	COMM_TYPE_N_SPLIT = 3,
	COMM_TYPE_N_SPLIT_REVERSE = 4,
	COMM_TYPE_HALF = 5,
	COMM_TYPE_RANDOM = 6,
	COMM_TYPE_MAX = 7,
};

struct coll_sharp_component_t {
	struct sharp_coll_context *sharp_coll_context;
	int is_leader;
	int ppn;
	int node_local_rank;
};
typedef struct coll_sharp_component_t coll_sharp_component_t;

struct coll_sharp_module_t {
	struct sharp_coll_comm *sharp_coll_comm;
	MPI_Comm comm;
};
typedef struct coll_sharp_module_t coll_sharp_module_t;
extern coll_sharp_component_t coll_sharp_component;
extern sharp_conf_t sharp_conf;

void coll_test_sharp_allreduce_complex(coll_sharp_module_t *sharp_comm);
void coll_test_sharp_allreduce_basic(coll_sharp_module_t *sharp_comm);
void coll_test_sharp_allreduce_perf(coll_sharp_module_t *sharp_comm);

void coll_test_sharp_iallreduce_complex(coll_sharp_module_t *sharp_comm);
void coll_test_sharp_iallreduce_basic(coll_sharp_module_t *sharp_comm);
void coll_test_sharp_iallreduce_perf(coll_sharp_module_t *sharp_comm);

void coll_test_sharp_barrier_complex(coll_sharp_module_t *sharp_comm);
void coll_test_sharp_barrier_basic(coll_sharp_module_t *sharp_comm);
void coll_test_sharp_barrier_perf(coll_sharp_module_t *sharp_comm);

#define __GETTIMEOFDAY 0
#define __CLOCK_GETTIME 1

#define __TIMER __CLOCK_GETTIME

#define SHARP_MSEC_PER_SEC   1000ull       /* Milli */
#define SHARP_USEC_PER_SEC   1000000ul     /* Micro */
#define SHARP_NSEC_PER_SEC   1000000000ul  /* Nano */

#if __TIMER == __GETTIMEOFDAY
static inline double sharp_time_sec(void)
{
	double wtime;
	struct timeval tv;
	gettimeofday(&tv, NULL);
	wtime = tv.tv_sec;
	wtime += (double)tv.tv_usec / SHARP_USEC_PER_SEC;
	return wtime;
}
#elif __TIMER == __CLOCK_GETTIME
static inline double sharp_time_sec()
{
	struct timespec tv;
	double wtime;
	clock_gettime(CLOCK_MONOTONIC, &tv);
	wtime  = (tv.tv_sec );
	wtime += (double)(tv.tv_nsec)/ SHARP_NSEC_PER_SEC;
	return wtime;
}
#else
	#error "unknown timer"
#endif

#define sharp_time_msec()  (sharp_time_sec() * SHARP_MSEC_PER_SEC)
#define sharp_time_usec() (sharp_time_sec() * SHARP_USEC_PER_SEC)
#define sharp_time_nsec() (sharp_time_sec() * SHARP_NSEC_PER_SEC)
#endif /*SHARP_MPI_TEST_H*/
