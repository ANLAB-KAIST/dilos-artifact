/**
 * Copyright (C) Mellanox Technologies Ltd. 2015-2016.  ALL RIGHTS RESERVED.
 * See file LICENSE for terms.
 */


#include <coll_test.h>

int client_id;
int max_payload_size = 256;   /* max test buffer size*/
int enable_sharp_coll = 0;
int sharp_world_rank;
int sharp_world_size;
int perf_test_iterations = 1000;
int perf_test_skips = 100;
int perf_with_barrier = 1;
int nbc_count = 512;
int sharp_test_group_type = -1;
int sharp_test_num_splits = 2; /* default odd even comm split */
coll_sharp_component_t coll_sharp_component;

static struct option long_options[] = {
	{"help", no_argument, NULL, 'h'},
	{"ib-dev", required_argument, NULL, 'd'},
	{"max_groups", required_argument, NULL, 'g'},
	{"group_type", required_argument, NULL, 't'},
	{"mode", required_argument, NULL, 'm'},
	{"collectives", required_argument, NULL, 'c'},
	{"iters", required_argument, NULL, 'i'},
	{"skips", required_argument, NULL, 'x'},
	{"perf_with_barrier", required_argument, NULL, 'B'},
	{"nbc_count", required_argument, NULL, 'N'},
	{0, 0, 0, 0}
};

static const char usage_string[] =
        "usage:   sharp_mpi_test  [-h | --help] \n"
        "\t\t\t [--max_groups <number>] [--ib-dev <hca>:<port>]\n"
        "\t\t\t [--max_qps <number> [--mode <basic|complex|perf|all>]\n"
	"\t\t\t [--collectives [allreduce|iallreduce|barrier|none]] [--iters <number>]\n"
	"\t\t\t [--group_type <world|world-dup|world-rev|half|split[:n]|split-rev[:n]]\n"
	"\t\t\t [--skips <number>] [--perf_with_barrier <1|0>]\n"
	"\t\t\t [--nbc_count <number>]\n"
        "--ib-dev, -d\n\tIB device name."
        "Use IB device <dev>:<port> (default first device found and port 1)\n\n"
        "--max_groups\n\tset value of max_groups. "
        "value must be non-negative (the default value is 1(COMM_WORLD))\n\t"
	"For value > 1 , The groups will be loop over different type of communicators(comm world,\n\t"
	"comm world dup, comm world reverse, comm world odd even split, comm world odd even split reverse)\n\n"
	"--group_type\n\tset specific group type(world, world-dup, world-rev, slipt:<n> split-rev:<n>) to test\n\n"
        "--mode\n\ttest mode (basic, complex, perf, all) default is basic\n\n "
	"--collectives \n\tcomma separated list of collectives to run.\n\t"
	"value must be valid collectives names(allreduce, iallreduce, barrier). default runs blocking collectives\n\n"
	"--iters \n\tnumber of iterations to run perf benchmark\n\n"
	"--skips \n\tnumber of warmup iterations to run perf benchmark\n\n"
	"--nbc_count \n\tnumber of non-blocking operation posted before waiting for completion (max: 512)\n\n"
	"--perf_with_barrier \n\tadd barrier in each perf iteration\n\n"
        "--help, -h\n\tDisplay this usage info, then exit\n\n";

const char *err_msg[] = {
	[INVALID_ARG] = "Either a non-existing command was specified,"
		" or an option with a missing argument was given",
	[INVALID_MAX_GROUPS] = "invalid value given for max_groups",
	[INVALID_GROUP_TYPE] = "invalid value given for group_type",
	[INVALID_TEST_MODE] = "invalid value given for mode",
	[INVALID_COLL_LIST] = "invalid list of collectives given"
};

sharp_conf_t sharp_conf = {
	.max_groups     = 1,
	.rank           = 0,
	.size           = 0,
	.ib_port        = 0,
	.hostlist       = NULL,
	.jobid          = 0,
	.ib_dev_list	= NULL,
	.ib_devname     = NULL,
	.test_mode      = 0,
	.run_allreduce  = 1,
	.run_allreduce  = 0,
	.run_barrier	= 1

};
int oob_bcast(void *comm_context, void *buf, int size, int root)
{
	MPI_Comm comm;
	if (comm_context == NULL) {
		comm = MPI_COMM_WORLD;
	} else {
		comm = ((coll_sharp_module_t *) comm_context)->comm;
	}
	MPI_Bcast(buf, size, MPI_BYTE, root, comm);
	return 0;
}

int oob_barrier(void *comm_context)
{
	MPI_Comm comm;
	if (comm_context == NULL) {
		comm = MPI_COMM_WORLD;
	} else {
		comm = ((coll_sharp_module_t*) comm_context)->comm;
	}
	MPI_Barrier(comm);
	return 0;
}
int oob_gather(void *comm_context, int root, void *sbuf, void *rbuf, int len)
{
	MPI_Comm comm;
	if (comm_context == NULL) {
		comm = MPI_COMM_WORLD;
	} else {
		comm = ((coll_sharp_module_t*) comm_context)->comm;
	}
	MPI_Gather(sbuf, len, MPI_BYTE, rbuf, len, MPI_BYTE, root, comm);
	return 0;
}


static void setup_comm_manager_rank(MPI_Comm comm, coll_sharp_component_t *sharp)
{
	int  name_length, size, i, rank;

	char name[MPI_MAX_PROCESSOR_NAME];

	MPI_Comm_rank(comm, &rank);
	MPI_Comm_size(comm, &size);

	/* todo: do not use stack allocation but malloc */
	int name_len[size];
	int offsets[size];

	MPI_Get_processor_name(name, &name_length);

	/* collect hostname len from all ranks */
	MPI_Allgather(&name_length, 1, MPI_INT, &name_len[0], 1, MPI_INT, comm);


	/* calculate receive buffer byte count based on hostname len sum. */
	int bytes = 0;
	for (i = 0; i < size; ++i) {
            offsets[i] = bytes;
            bytes += name_len[i];
	}
        bytes++;

	char receive_buffer[bytes];
	receive_buffer[bytes-1] = 0;

	// collect hostnames, form comma separated list
	MPI_Allgatherv(&name[0], name_length, MPI_CHAR, &receive_buffer[0], &name_len[0], &offsets[0], MPI_CHAR, comm);

        int node_rank_count = 0;
        int node_rank_min = rank;

        for (i=0; i<size; i++) {
            int idx = offsets[i];
            int len = name_len[i];

            if (name_length != len) {
                continue;
            }

            if (0 == strncmp(name, &receive_buffer[idx], len)) {
		if (i == rank) {
			sharp->node_local_rank = node_rank_count;
#if 0
			printf(stdout"rank:%d local rank:%d\n", i, sharp->node_local_rank);
#endif
		}
                node_rank_count++;
                if (node_rank_min > i) {
                    node_rank_min = i;
                }
            }
        }

        sharp->is_leader = (rank == node_rank_min);
        sharp->ppn = node_rank_count;
}

int coll_component_open(void)
{
	int ret;
	struct sharp_coll_init_spec init_spec = {0};

	if (!enable_sharp_coll)
		return 0;

	setup_comm_manager_rank(MPI_COMM_WORLD, &coll_sharp_component);

	init_spec.progress_func  = NULL;
	init_spec.job_id = 1;
	init_spec.hostlist = sharp_conf.hostlist;
	init_spec.world_rank = sharp_world_rank;
	init_spec.world_local_rank = coll_sharp_component.node_local_rank;
	init_spec.enable_thread_support = 0;
	init_spec.world_size = sharp_world_size;
	init_spec.group_channel_idx = coll_sharp_component.node_local_rank;
	init_spec.oob_colls.barrier = oob_barrier;
	init_spec.oob_colls.bcast = oob_bcast;
	init_spec.oob_colls.gather = oob_gather;
	init_spec.config = sharp_coll_default_config;
	init_spec.config.ib_dev_list = sharp_conf.ib_dev_list;


	ret = sharp_coll_init(&init_spec, &coll_sharp_component.sharp_coll_context);
	return ret;
}

int coll_module_enable(MPI_Comm comm, coll_sharp_module_t *sharp_module)
{
	int size, rank, ret;
	struct sharp_coll_comm_init_spec comm_spec;

	MPI_Comm_size(comm, &size);
	MPI_Comm_rank(comm, &rank);

	sharp_module->comm = comm;

	if (!enable_sharp_coll)
		return 0;

	comm_spec.rank = rank;
	comm_spec.size = size;
	comm_spec.is_comm_world = (comm == MPI_COMM_WORLD);
	comm_spec.oob_ctx = sharp_module;
	comm_spec.group_world_ranks = NULL;
	ret = sharp_coll_comm_init(coll_sharp_component.sharp_coll_context,
			     &comm_spec, &sharp_module->sharp_coll_comm);
	if (ret < 0) {
		fprintf(stdout,"sharp communicator creation failed: %s\n", sharp_coll_strerror(ret));
		return -1;
	}
	return 0;
}

void coll_module_destroy(coll_sharp_module_t *sharp_module)
{
	if (!enable_sharp_coll)
		return;
	sharp_coll_comm_destroy(sharp_module->sharp_coll_comm);

}
void coll_component_close(void)
{
	if (!enable_sharp_coll)
		return;
	sharp_coll_finalize(coll_sharp_component.sharp_coll_context);
}

static void sharp_run_basic(coll_sharp_module_t *sharp_comm)
{
	if (sharp_conf.run_allreduce)
		coll_test_sharp_allreduce_basic(sharp_comm);
	if (sharp_conf.run_iallreduce)
		coll_test_sharp_iallreduce_basic(sharp_comm);
	if (sharp_conf.run_barrier)
		coll_test_sharp_barrier_basic(sharp_comm);
}

static void sharp_run_complex(coll_sharp_module_t *sharp_comm)
{
	if (sharp_conf.run_allreduce)
		coll_test_sharp_allreduce_complex(sharp_comm);
	if (sharp_conf.run_iallreduce)
		coll_test_sharp_iallreduce_complex(sharp_comm);
	if (sharp_conf.run_barrier)
		coll_test_sharp_barrier_complex(sharp_comm);
}
static void sharp_run_perf(coll_sharp_module_t *sharp_comm)
{
	if (sharp_conf.run_allreduce)
		coll_test_sharp_allreduce_perf(sharp_comm);
	if (sharp_conf.run_iallreduce)
		coll_test_sharp_iallreduce_perf(sharp_comm);
	if (sharp_conf.run_barrier)
		coll_test_sharp_barrier_perf(sharp_comm);
}

void coll_module_op(coll_sharp_module_t *sharp_comm)
{
	if (sharp_conf.test_mode == TEST_BASIC) {
		sharp_run_basic(sharp_comm);
	} else if (sharp_conf.test_mode == TEST_COMPLEX) {
		sharp_run_complex(sharp_comm);
	} else if (sharp_conf.test_mode == TEST_PERF) {
		sharp_run_perf(sharp_comm);
	} else {
		sharp_run_basic(sharp_comm);
		sharp_run_complex(sharp_comm);
		sharp_run_perf(sharp_comm);
	}
}


void sharp_setenv(char *sharp_var, char *env_var, char *default_val)
{
	char *tmp = getenv(env_var);

	if (NULL == tmp) {
		if (NULL != default_val) {
			tmp = default_val;
		} else {
			return;
		}
	}
	setenv(sharp_var, tmp, 0);
}

void sharp_env2int(char *env_var, int *val, int default_val)
{
	long tmp;
	char *endptr, *str;

	*val = default_val;

	str = getenv(env_var);
	if (NULL == str)
		return;

	tmp = strtol(str, &endptr, 10);
	if (*endptr != '\0') {
		fprintf(stdout,"Invalid  %s environment value\n", env_var);
	} else {
		*val = tmp;
	}
}

void mpi_get_communicator(MPI_Comm *comm, int group_num)
{
	int size, rank;
	static int comm_idx;

	MPI_Comm_size(MPI_COMM_WORLD, &size);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	if (sharp_test_group_type >= 0)
		comm_idx = sharp_test_group_type;

	switch (comm_idx) {
	case COMM_TYPE_WORLD:
		*comm = MPI_COMM_WORLD;
		break;
	case COMM_TYPE_WORLD_DUP:
		/* dup of comm_world */
		MPI_Comm_dup(MPI_COMM_WORLD, comm );
		break;
	case COMM_TYPE_WORLD_REVERSE:
		/*reverse comm */
		MPI_Comm_split(MPI_COMM_WORLD, 0, size-rank, comm);
		break;
	case COMM_TYPE_N_SPLIT:
		/* subset of world. odd, even groups */
		MPI_Comm_split( MPI_COMM_WORLD, (rank % sharp_test_num_splits), rank, comm);
		break;
	case COMM_TYPE_N_SPLIT_REVERSE:
		/* subset of world. odd, even groups in reserse*/
		MPI_Comm_split( MPI_COMM_WORLD, (rank % sharp_test_num_splits), (size - rank), comm);
		break;
	case COMM_TYPE_HALF:
		MPI_Comm_split(MPI_COMM_WORLD, (rank < (size/2)), rank, comm);
		break;
	case COMM_TYPE_RANDOM:
		/* TODO: random comm with random size */
	default:
		*comm = MPI_COMM_WORLD;
	}

	comm_idx++;

	/* repease comm types for all groups.
	*/
	if(comm_idx == COMM_TYPE_MAX) {
		comm_idx = 1;
	}

}

void mpi_free_comm(MPI_Comm *comm)
{
	if (*comm != MPI_COMM_WORLD &&
	    *comm != MPI_COMM_NULL) {
		MPI_Comm_free(comm );
	}
}


void mpi_create_hostlist(void)
{
	int  name_length, size, i, rank;

	char name[MPI_MAX_PROCESSOR_NAME];

	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	// todo: do not use stack allocation but malloc
	int name_len[size];
	int offsets[size];

	// read hostname
	MPI_Get_processor_name(name, &name_length);

	// append comma to make a list
	if (rank < size-1) {
		name[name_length++] = ',';
	}

	// collect hostname len from all ranks
	MPI_Allgather(&name_length, 1, MPI_INT, &name_len[0], 1, MPI_INT, MPI_COMM_WORLD);


	// calculate receive buffer byte count based on hostname len sum.
	int bytes = 0;
	for (i = 0; i < size; ++i) {
		offsets[i] = bytes;
		bytes += name_len[i];
	}
	bytes++; // reserve space for \n

	char receive_buffer[bytes];
	receive_buffer[bytes-1] = 0;

	// collect hostnames, form comma separated list
	MPI_Allgatherv(&name[0], name_length, MPI_CHAR, &receive_buffer[0], &name_len[0], &offsets[0], MPI_CHAR, MPI_COMM_WORLD);

	setenv("MPI_TEST_NODES", (char *)&receive_buffer,1);
}


void setup_sharp_env(sharp_conf_t *sharp_conf)
{
	mpi_create_hostlist();

	sharp_setenv("SHARP_SIZE",  "OMPI_COMM_WORLD_SIZE",    NULL);
	sharp_setenv("SHARP_JOBID", "OMPI_MCA_ess_base_jobid", NULL);
	sharp_setenv("SHARP_NODES", "MPI_TEST_NODES", NULL);

	MPI_Comm_size(MPI_COMM_WORLD, &sharp_conf->size);
	MPI_Comm_rank(MPI_COMM_WORLD, &sharp_conf->rank);

	sharp_conf->hostlist = getenv("SHARP_NODES");
	sharp_conf->jobid = getenv("SHARP_JOBID");

	sharp_env2int("MAX_PAYLOAD_SIZE", &max_payload_size, max_payload_size);
	sharp_env2int("ENABLE_SHARP_COLL", &enable_sharp_coll, enable_sharp_coll);

}

static void parse_hca(char *optarg, sharp_conf_t *sharp_conf)
{
	char *endptr, *saveptr;
	free(sharp_conf->ib_dev_list);
	sharp_conf->ib_dev_list = strdup(optarg);
	assert(optarg);
	sharp_conf->ib_devname = strdup(strtok_r(optarg, ":", &saveptr));
	endptr = strtok_r(NULL, ":", &saveptr);
	if (endptr)
		sharp_conf->ib_port = atoi(endptr);
}

int parse_opts(int argc, char **argv, sharp_conf_t *sharp_conf)
{
	int opt, option_index;
	int res = PARSE_ARGS_OK;
	long tmp;
	long tmp_id = 0;
	char *endptr, *saveptr, *tmp_ptr = NULL;

	/* hack to pass hca from env */

	char *user_hca = getenv("IB_DEV");

	if (user_hca) {
		parse_hca(user_hca, sharp_conf);
	}


	while (res == PARSE_ARGS_OK) {
		tmp = 0;
		option_index = 0;
		endptr = "\0";
		opt = getopt_long(argc, argv, "h:t:d:m:c:i:x:B:N:", long_options, &option_index);
		if (opt == -1) //no more args to parse
			break;
		switch (opt) {
		case 'h':
			res = PARSE_ARGS_HELP;
			break;
		case 'c':
			sharp_conf->run_allreduce  = 0;
			sharp_conf->run_iallreduce  = 0;
			sharp_conf->run_barrier  = 0;
			saveptr = optarg;
			for (endptr = strtok_r(optarg, ",", &saveptr);
				endptr; endptr = strtok_r(NULL, ",", &saveptr)) {
				if (strcmp(endptr, "allreduce") == 0) {
					sharp_conf->run_allreduce = 1;
				} else if (strcmp(endptr, "iallreduce") == 0) {
					sharp_conf->run_iallreduce = 1;
				} else if(strcmp(endptr, "barrier") == 0) {
					sharp_conf->run_barrier = 1;
				} else if(strcmp(endptr, "none") == 0) {
					sharp_conf->run_allreduce = 0;
					sharp_conf->run_iallreduce  = 0;
					sharp_conf->run_barrier = 0;
				} else {
					res = INVALID_COLL_LIST;
				}
			}
			break;
		case 't':
			saveptr = optarg;
			endptr = strtok_r(optarg, ":", &saveptr);
			if (endptr) {
				if (strcmp(endptr, "world") == 0) {
					sharp_test_group_type = COMM_TYPE_WORLD;
				} else if (strcmp(endptr, "world-dup") == 0) {
					sharp_test_group_type = COMM_TYPE_WORLD_DUP;
				} else if (strcmp(endptr, "world-rev") == 0) {
					sharp_test_group_type = COMM_TYPE_WORLD_REVERSE;
				} else if (strcmp(endptr, "split") == 0) {
					sharp_test_group_type = COMM_TYPE_N_SPLIT;
					endptr = strtok_r(NULL, ",", &saveptr);
					if (endptr) {
						sharp_test_num_splits = strtol(endptr, &tmp_ptr, 10);
						if (*tmp_ptr != '\0') {
							res = INVALID_GROUP_TYPE;
						}
					}
				} else if (strcmp(endptr, "split-rev") == 0) {
					sharp_test_group_type = COMM_TYPE_N_SPLIT_REVERSE;
					endptr = strtok_r(NULL, ",", &saveptr);
					if (endptr) {
						sharp_test_num_splits = strtol(endptr, &tmp_ptr, 10);
						if (*tmp_ptr != '\0') {
							res = INVALID_GROUP_TYPE;
						}
					}
				} else if(strcmp(endptr, "half") == 0) {
					sharp_test_group_type = COMM_TYPE_HALF;
				} else {
					res = INVALID_GROUP_TYPE;
				}
			} else {
				res = INVALID_GROUP_TYPE;
			}
			break;

		case 'd':
			parse_hca(optarg, sharp_conf);
			break;
		case 'g':
			tmp = strtol(optarg, &endptr, 10);
			if (*endptr != '\0') {
				res = INVALID_MAX_GROUPS;
			} else {
				if (tmp >= INT_MAX || tmp < 0)
					res = INVALID_MAX_GROUPS;
				else
					sharp_conf->max_groups = tmp;
			}
			break;
		case 'm':
			if (0 == strcmp(optarg, "basic"))
				sharp_conf->test_mode = TEST_BASIC;
			else if (0 == strcmp(optarg, "complex"))
				sharp_conf->test_mode = TEST_COMPLEX;
			else if (0 == strcmp(optarg, "perf"))
				sharp_conf->test_mode = TEST_PERF;
			else if (0 == strcmp(optarg, "all"))
				sharp_conf->test_mode = TEST_ALL;
			else
				res = INVALID_TEST_MODE;
			break;
		case 'i':
			tmp_id = strtol(optarg, &endptr, 10);
			if (*endptr != '\0' || tmp_id < 0)
				res = INVALID_ARG;
			else
				perf_test_iterations = tmp_id;
			break;
		case 'x':
			tmp_id = strtol(optarg, &endptr, 10);
			if (*endptr != '\0' || tmp_id < 0)
				res = INVALID_ARG;
			else
				perf_test_skips = tmp_id;
			break;
		case 'N':
			tmp_id = strtol(optarg, &endptr, 10);
			if (*endptr != '\0' || tmp_id < 0 || tmp_id > 512)
				res = INVALID_ARG;
			else
				nbc_count = tmp_id;
			break;
		case 'B':
			tmp_id = strtol(optarg, &endptr, 10);
			if (*endptr != '\0' || tmp_id < 0)
				res = INVALID_ARG;
			else
				perf_with_barrier = tmp_id;
			break;
		default:
			res = INVALID_ARG;
		}
	}

	if (opt == -1 && argv[optind] != NULL)
		res = INVALID_ARG;
	return res;
}

void print_parser_msg(int parse_res)
{
	if (parse_res == PARSE_ARGS_HELP)
		printf("%s\n", usage_string);
	else if (parse_res == INVALID_ARG)
		fprintf(stderr,"ERROR. Either a non-existing command was specified, "
			"or an option with a missing argument was given\n\n");
	else
		fprintf(stderr, "ERROR - %s\n\n", err_msg[parse_res]);
}

const char *sharp_get_host_name(void)
{
    static char hostname[256] = {0};

    if (*hostname == 0) {
        gethostname(hostname, sizeof(hostname));
        strtok(hostname, ".");
    }
    return hostname;
}


int main(int argc, char **argv)
{
	int rank, size, parse_res;
	int ret = 0, i;
	MPI_Comm mpi_comm;
	coll_sharp_module_t **sharp_comm = NULL;
	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	sharp_world_rank = rank;
	sharp_world_size = size;

	parse_res = parse_opts(argc, argv, &sharp_conf);
	//if we got an invalid command argument (or 'help' flag) - don't run test:
	if (parse_res != PARSE_ARGS_OK) {
		if (rank == 0) {
			print_parser_msg(parse_res);
			if (parse_res != PARSE_ARGS_HELP) {
				// print the help message after the error message:
				print_parser_msg(PARSE_ARGS_HELP);
				ret = -1;
			}
		}
		goto out;
	}

	setup_sharp_env(&sharp_conf);


	if (0 == coll_component_open()) {
		sharp_comm = (struct coll_sharp_module_t **)
			malloc(sizeof(struct coll_sharp_module_t *) * sharp_conf.max_groups);
		if (!sharp_comm) {
			fprintf(stdout,"memory allocation failed\n");
			ret = -1;
			goto out;
		}
		for (i = 0; i < sharp_conf.max_groups; i++) {
			sharp_comm[i] = calloc(1, sizeof(struct coll_sharp_module_t));
			if (!sharp_comm[i]) {
				fprintf(stdout,"memory allocation failed\n");
				ret = -1;
				goto out;
			}
			mpi_get_communicator(&mpi_comm, i);
			if (0 == coll_module_enable(mpi_comm, sharp_comm[i])) {
				// run collective op from this module
				coll_module_op(sharp_comm[i]);

				// tears down
				coll_module_destroy(sharp_comm[i]);
			} else {
				if (mpi_comm == MPI_COMM_WORLD) {
					fprintf(stdout,"sharp comm create failed for MPI_COMM_WORLD. Aborting..\n");
					mpi_free_comm(&mpi_comm);
					free(sharp_comm[i]);
					ret = -1;
					goto out;
				}
			}
			mpi_free_comm(&mpi_comm);
			free(sharp_comm[i]);
		}

	} else {
		if (rank == 0)
			fprintf(stdout,"SHArP coll failed to initialize..\n");
		ret = -1;
		goto out;
	}

	MPI_Barrier(MPI_COMM_WORLD);

	coll_component_close();
out:
	free(sharp_comm);
	MPI_Finalize();
	return ret;
}
