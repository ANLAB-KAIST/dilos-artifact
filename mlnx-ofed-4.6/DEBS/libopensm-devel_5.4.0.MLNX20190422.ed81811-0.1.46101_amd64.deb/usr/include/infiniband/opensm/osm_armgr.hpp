/*                  - Mellanox Confidential and Proprietary -
 *
 *  Copyright (C) 2010-2011, Mellanox Technologies Ltd.  ALL RIGHTS RESERVED.
 *
 *  Except as specifically permitted herein, no portion of the information,
 *  including but not limited to object code and source code, may be reproduced,
 *  modified, distributed, republished or otherwise exploited in any form or by
 *  any means for any purpose without the prior written permission of Mellanox
 *  Technologies Ltd. Use of software subject to the terms and conditions
 *  detailed in the file "COPYING".
 *
 */


#ifndef AR_MGR_H_
#define AR_MGR_H_

/* osm_config.h needs to be before all other includes */
#include <opensm/osm_config.h>
#include <typeinfo>
#include <string>
#include <stack>
using namespace std;

#include <opensm/osm_opensm.h>
#include <opensm/osm_helper.h>
#include <opensm/osm_log.h>
#include <opensm/osm_event_plugin.h>
#include <vendor/osm_vendor_api.h>


#include "opensm/osm_armgr_types.hpp"
using namespace OSM;

#include "opensm/osm_parallel_port_groups_calculator.hpp"
typedef vector <bool> BoolVec;
typedef map <u_int64_t, u_int16_t> GuidToGroupMap;
typedef GuidToGroupMap::iterator GuidToGroupMapIter;

//============================================================================//
class OSMAdaptiveRoutingManager {
public:
    ////////////////////
    //methods
    ////////////////////

    /**
     * Constructor OSMAdaptiveRoutingManager
     *
     * @param p_osm pointer to OpenSM structure
     */
    OSMAdaptiveRoutingManager(osm_opensm_t *p_osm);

    /**
     *  Destructor OSMAdaptiveRoutingManager
     */
    ~OSMAdaptiveRoutingManager();

    /**
     * Set osm_event_id
     *
     * @param osm_event_id
     */
    void SetOSMEventId(osm_epi_event_id_t osm_event_id);

    /**
     * Update fabric nodes. Update node info for all nodes
     *
     * @return int 0 if succeeded, otherwise 1
     */
    void UpdateFabricSwitches();

    /**
     * Configure all nodes the support adaptive routing in the
     * fabric with adaptove routing parameters with user defined
     * parameters or default if none where given.
     *
     * @return int return 1 is succeeded, otherwise 0
     */
    int Construct();
    
    /*
     * Run an adaptive routing manager preprocessing phase
     */
    int Preprocess();

    /*
     * Run an adaptive routing manager preprocessing phase
     */
    int Route();

    /**
     * Calculate adaptive routing settings according to fat tree algorithm 
     * for the given sw_db_entry 
     */
    void ARCalculateSwitchPortGroupsTree(
        ARSWDataBaseEntry &sw_db_entry,
        uint8_t max_rank,
        u_int16_t *hca_to_sw_lid_mapping,
        uint8_t *sw_lid_to_rank_mapping);

    /**
     * Dump the switch adaptive routing settings
     *
     * @param sw_db_entry the entry of the switch in the db
     */
    void ARDumpSWSettings(ARSWDataBaseEntry &sw_db_entry);

    /**
     * Print Exception
     *
     * @param e exception
     * @param p_osm_log log file
     */
    static void printException(exception& e, osm_log_t * p_osm_log) {
        string e_what(e.what( ));
        string e_type(typeid(e).name( ));
        OSM_LOG(p_osm_log, OSM_LOG_ERROR,
                "AR_MGR - caught an exception: %s. Type: %s\n",
                e_what.c_str(), e_type.c_str());
    }

    /**
     * Decide if two adaptive_routing_info structs are equal or not
     *
     * @param p_ar_info1 struct one to compare
     * @param p_ar_info2 struct two to compare
     * @param ignoreE if true, do not compare E attribute
     *
     * @return true if equal or false otherwise
     */
    static bool IsEqualSMPARInfo(ib_ar_info_t *p_ar_info1, ib_ar_info_t *p_ar_info2,
                                 bool ignoreE, bool ignoreTop);

private:
    ////////////////////
    //members
    /////////////////////
    u_int64_t                       m_port_guid;            /** Port guid to bind for */
    osm_epi_event_id_t              m_osm_event_id;         /** OSM event id */
    osm_opensm_t                    *m_p_osm;               /** Pointer to osm opensm struct */
    osm_vendor_t                    *m_p_osm_vendor;        /** Pointer to osm vendor struct */
    osm_subn_t                      *m_p_osm_subn;          /** Pointer to osm subnet struct */
    osm_log_t                       *m_p_osm_log;           /** Pointer to osm log */

    OSMThreadPool                   m_thread_pool;
    OSMParallelPortGroupsCalculator m_port_groups_calculator;

    struct ARSWDataBase             m_sw_db;                /** Switchs database */
    struct MasterDataBase           m_master_db;            /** Master settings database */

    string                          m_conf_file_name;       /** Name of user input file */

    int                             m_oldest_error;         /** index of oldest error in error window array */
    unsigned int                    m_num_errors;           /** Number of errors */
    struct timeval                  *m_p_error_window_arr;  /** Error window array */

    bool                            m_is_permanent_error;   /** Indicates permanent error occurred
                                                                                 * (will not be solved after heavy sweep) */
    bool                            m_is_temporary_error;   /** Indicates temporary error occurred
                                                                                 * (will be solved after heavy sweep) */

    bool                            m_df_configured;        /** If true should remove df configuration
                                                             * if protocol is not DF PLUS*/

    bool                            m_sw_info_configured;  /** If true should remove sw info configuration
                                                             * if protocol is not DF PLUS*/

    uint16_t                        m_max_df_group_number;
    GuidToGroupMap                  m_guid_to_dfp_group;
    bool                            m_group_discovered;

    uint32_t                        m_options_file_crc;

    ////////////////////
    //methods
    ////////////////////
    /**
     * Reset error window mechanism. Remove old errors
     */
    void ResetErrorWindow();

    /**
     * Set default configuration values
     */
    void SetDefaultConfParams();

    /**
     * Take the configuration values that have been parsed
     */
    void TakeParsedConfParams();

    /**
     * Check if file exists and have permissions
     *
     * @return true if exists, otherwise false
     */
    bool IsFileExists(const char *file_name);

    /**
     * Merge between default settings and user option settings
     */
    void UpdateUserOptions();

    /**
     * Check if more than m_max_errors occurred during the
     *  last m_error_window. If so, throw an exception
     *
     * @throw Throws int when condition holds
     *
     * @param rc return value that indicates if an error has occurred
     */
    void CheckRC(int& rc);

    /**
     * Parse OSM parameters for cc_mgr conf file
     *
     * @param osm_params
     */
    void ParseConfFileName(char* osm_plugin_options);

    /**
     * Initialize objects.
     * Bind port to AR mads
     *
     * @return int 0 if succeeded, otherwise throw exception with int 1
     */
    int Init();

    /**
     * Check if device id is supported.
     *
     * @param node_info node info holds device id
     *
     * @return bool true if supported, otherwise false
     */
    bool IsDeviceIDSupported(const ARGeneralSWInfo& general_sw_info);

    /**
     * Update Switch from sm database to local database
     *
     * @param node_info node info
     *
     * @return int 0 if succeeded, otherwise 1
     */
    void UpdateSW(const ARGeneralSWInfo& general_sw_info);

    /**
     * Add switches that don't exist ar_mgr from osm database
     *  and update all switches in ar_mgr

     */
    void AddNewAndUpdateExistSwitches();

    /**
     * Remove switches that don't exist in m_p_osm_subn
     *  from ar_mgr database
     */
    void RemoveAbsentSwitches();

    /**
     * Mark switch as not supports for feature for all future cycles
     *
     * @param sw_db_entry the entry of the switch in the db
     * @param feature [AR|DF|RN]
     * @param type the reason that this switch is marked as not supports
     */
    //void MarkSWNotSupport(ARSWDataBaseEntry &sw_db_entry,
    //                      supported_feature_t feature,
    //                      support_errs_t type);
    /**
     * Check if switch supports for feature
     *
     * @param sw_db_entry the entry of the switch in the db
     * @param feature [AR|DF|RN]
     * @return true if supported or false otherwise
     */
    //bool IsNotSupported(ARSWDataBaseEntry &sw_db_entry,
    //                    supported_feature_t feature);

    /**
     * Mark switch as not supports for adaptive routing for all future cycles
     *
     * @param sw_db_entry the entry of the switch in the db
     * @param type the reason that this switch is marked as not supports
     */
    void MarkSWNotSupportAR(ARSWDataBaseEntry &sw_db_entry,
            support_errs_t type);

    /**
     * Check if switch supports for adaptive routing
     *
     * @param sw_db_entry the entry of the switch in the db
     *
     * @return true if supported or false otherwise
     */
    bool IsARNotSupported(ARSWDataBaseEntry &sw_db_entry);

    /**
     * Mark switch as supports for adaptive routing
     *
     * @param sw_db_entry the entry of the switch in the db
     */
    void MarkSWSupportAR(ARSWDataBaseEntry &sw_db_entry);

    /**
     * Check if adaptive routing is active in a switch (both support and enable)
     *
     * @param sw_db_entry the entry of the switch in the db
     *
     * @return true if active or false otherwise
     */
    bool IsARActive(ARSWDataBaseEntry &sw_db_entry);

    /**
     * Check if Dragonfly is active in a switch (both support and AR
     * enable)
     *
     * @param sw_db_entry the entry of the switch in the db
     *
     * @return true if active or false otherwise
     */
    bool IsDFActive(ARSWDataBaseEntry &sw_db_entry);

    /**
     * Mark all switch as supports / not supports adaptive routing
     *
     * @return number of unsupportes switches
     *
     */
    int ARInfoGetProcess();

    /**
     * Set Required ARInfo R/W values for all supportes switches
     *
     */
    void SetRequiredARInfo(ARSWDataBaseEntry &db_entry);
    /**
     * Get calculated GroupCap from all supportes switches
     *
     * @return number of unsupportes switches
     *
     */
    int  ARInfoGetGroupCapProcess();

    /**
     *  Configure ARInfo on needed ones
     *
     * @return number of unsupportes switches
     *
     */
    int ARInfoSetProcess();

    /**
     *  Configure RoutingNotification tree settings on needed
     *  switches
     *
     *
     */
    void TreeRoutingNotificationProcess();

    /**
     * Update DB used to copy a single group to moltiple
     * groups
     *
     * @param sw_db_entry the entry of the switch in the db
     * @param assign_groups the calculated GroupsList object
     */
    void ARUpdateSWGroupToCopy(
        ARSWDataBaseEntry &sw_db_entry,
        GroupsList &assign_groups);

    /**
     * Update update a single GroupElement in the switch group table
     *
     * @param sw_db_entry the entry of the switch in the db
     * @param calculated_element the calculated group element
     * @param group_number the calculated group number
     */
    void ARUpdateSWGroupElement(
        ARSWDataBaseEntry &sw_db_entry,
        osm_ar_subgroup_t &calculated_element,
        u_int16_t group_number);

    /**
     * Update the switch group table with the calculated one
     *
     * @param sw_db_entry the entry of the switch in the db
     * @param p_ar_calculated_group_table the calculated group table
     * @param calculated_groups_number total groups number in the calculated table
     */
    void ARUpdateSWGroupTable(ARSWDataBaseEntry &sw_db_entry,
            osm_ar_subgroup_t p_ar_calculated_group_table[],
            u_int16_t calculated_groups_number);

    /**
     * Update the switch lft table with the calculated one
     *
     * @param sw_db_entry the entry of the switch in the db
     * @param p_ar_calculated_lft_table the calculated lft table
     * @param calculated_max_lid the last lid that is valid in the calculated table
     */
    void ARUpdateSWLFTTable(ARSWDataBaseEntry &sw_db_entry,
            struct SMP_ARLinearForwardingTable p_ar_calculated_lft_table[],
            u_int16_t calculated_max_lid);

    /**
     * Update the SX switch lft table with the calculated one
     *
     * @param sw_db_entry the entry of the switch in the db
     * @param p_ar_calculated_lft_table the calculated lft table
     * @param calculated_max_lid the last lid that is valid in the calculated table
     */
    void ARUpdateSWLFTTable(ARSWDataBaseEntry &sw_db_entry,
            struct SMP_ARLinearForwardingTable_SX p_ar_calculated_lft_table[],
            u_int16_t calculated_max_lid);

    void UpdateRNRcvString(ARSWDataBaseEntry &sw_db_entry,
                           uint8_t max_rank,
                           uint8_t sw_rank,
                           uint8_t max_consume_rank);

    void UpdateRNXmitPortMask(
            ARSWDataBaseEntry &sw_db_entry,
            PortsBitset &ca_ports,
            PortsBitset &sw_ports,
            bool is_down_sw);

    /**
     * Calculate adaptive routing settings according to parallel links algorithm
     */
    void ARCalculatePortGroupsParallelLinks();

    /**
     * Calculate adaptive routing settings according to fat tree algorithm
     */
    void ARCalculatePortGroupsTree();

    /**
     * Update data structures on adding new lid to AR groups
     */
    void AddLidToARGroup(uint16_t lid_num, uint16_t sw_lid_num,
                         GroupData* p_group_data,
                         TreeAlgorithmData &algorithm_data,
                         bool is_new_group,
                         bool is_group_per_leaf_sw);

    /**
     * Print the given group_data object to log file
     */
    void PrintGroupData(const char * str, GroupData &group_data);

    /**
     * Assign group number and table number to discovered groups
     */
    int AssignPortGroups(ARSWDataBaseEntry &sw_db_entry, TreeAlgorithmData &algorithm_data);

    int AssignPerLeafSwitchGroups(ARSWDataBaseEntry &sw_db_entry,
                                  TreeAlgorithmData &algorithm_data);

    int AssignToContainedGroup(ARSWDataBaseEntry &sw_db_entry, TreeAlgorithmData &algorithm_data, GroupData* group);
    int GetContainedGroupList(GroupsList& group_list, PortsBitset &group_bitmask, GroupsList& contained_group_list, PortsBitset &total_bitmask);

    /**
     * Get GroupList ordered by group size ad lids number
     */
    int GetOrderedGroupList(TreeAlgorithmData &algorithm_data, GroupsList& group_list);

    void ARCopyGroupTableProcess();

    /**
     * Mark all switch flags for osm
     *  Some switches were configured with adaptive routing and some need to
     *  be configured with osm with ucast lft table
     */
    void AROSMIntegrationProcess();

    /**
     * Map CAs lids to connected SW lid
     *
     * @param hca_to_sw_lid_mapping
     */
     int SetHcaToSwLidMapping(osm_physp_t *p_hca_physp,
                             osm_node_t *p_remote_sw_node,
                             u_int16_t *hca_to_sw_lid_mapping );

    //The allocation of group number to leaf sw is saved
    //after the first allocation
    u_int16_t AllocateSwArGroup(uint16_t sw_lid, uint16_t group_cap);

    /*
     * Wait for pending transactions.
     */
    void WaitForPendingTransactions();

    /*
     * Validate switches capabilities.
     */
    int ValidateSwitchesCapabilites();
};


#endif          /* AR_MGR_H_ */

