/*
 * Copyright (c) 2018 Mellanox Technologies LTD. ALL RIGHTS RESERVED.
 * See file LICENSE for terms.
 */

#ifndef CALCULATE_PORT_GROUPS_TASK_H
#define CALCULATE_PORT_GROUPS_TASK_H

#include <stdlib.h>

namespace OSM {

class OSMThreadPoolTask {

    bool    m_check_result_;

public:

    OSMThreadPoolTask() : m_check_result_(false) {}

    //Run should not throw for error handling.
    //It should change the tasks state instead.
    virtual void Run() = 0;
    virtual ~OSMThreadPoolTask() {}

    void SetCheckResult(bool is_check_result) {
        m_check_result_ = is_check_result;
    }

    bool IsCheckResult() {
        return m_check_result_;
    }
};

struct ARSWDataBaseEntry;
class OSMParallelPortGroupsCalculator;

class OSMCalculatePortGroupsTreeTask : public OSMThreadPoolTask {

    ARSWDataBaseEntry                *m_sw_db_entry_;
    OSMParallelPortGroupsCalculator  *m_port_groups_calculator_;

public:
    OSMCalculatePortGroupsTreeTask(
        OSMParallelPortGroupsCalculator *p_port_groups_calculator) :
        m_sw_db_entry_(),
        m_port_groups_calculator_(p_port_groups_calculator) {}

    virtual ~OSMCalculatePortGroupsTreeTask() {}

    void Init(ARSWDataBaseEntry *p_db_entry) {
        m_sw_db_entry_ = p_db_entry;
    }

    virtual void Run();
};

} //end of namespace OSM

#endif //CALCULATE_PORT_GROUPS_TASK_H
