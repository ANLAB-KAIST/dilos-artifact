/*
 * Copyright (c) 2017 Mellanox Technologies LTD. All rights reserved.
 *
 * This software is available to you under a choice of one of two
 * licenses.  You may choose to be licensed under the terms of the GNU
 * General Public License (GPL) Version 2, available from the file
 * COPYING in the main directory of this source tree, or the
 * OpenIB.org BSD license below:
 *
 *     Redistribution and use in source and binary forms, with or
 *     without modification, are permitted provided that the following
 *     conditions are met:
 *
 *      - Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer.
 *
 *      - Redistributions in binary form must reproduce the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer in the documentation and/or other materials
 *        provided with the distribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

/*
 * Abstract:
 * 	Declaration of osm_advanced_routing_data_t.
 *
 *	This object is part of the OpenSM family of objects.
 */

#ifndef _OSM_ADAPTIVE_ROUTING_H_
#define _OSM_ADAPTIVE_ROUTING_H_

#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else				/* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif				/* __cplusplus */

BEGIN_C_DECLS

/****s* OpenSM: Switch/osm_advanced_routing_data_t
* NAME
*	osm_advanced_routing_data_t
*
* DESCRIPTION
*	Adaptive Routing Data structure.
*
*	This object should be treated as opaque and should
*	be manipulated only through the provided functions.
*
* SYNOPSIS
*/


#define ADV_ROUTING_OPT_MODE_DISABLED		0
#define ADV_ROUTING_OPT_MODE_ENABLED		1
#define ADV_ROUTING_OPT_MODE_RN			2


/*
 * Forward declarations
 */
struct osm_sm;
struct osm_switch;

typedef struct osm_ar_subgroup {
	uint8_t mask[32];
} osm_ar_subgroup_t;
/*
* FIELDS
*/


typedef struct osm_ar_capability {
	cl_list_item_t list_item;
	ib_ar_info_t ar_info;
} osm_ar_capability_t;
/*
* FIELDS
*/


typedef struct osm_ar_tables {
	osm_ar_subgroup_t *ar_subgroups;
	ib_ar_lft_entry_t *ar_lft;
	uint8_t *rn_subgroup_direction;
	ib_net16_t *rn_direction_string;
	ib_rn_rcv_string_entry_t *rn_rcv_strings;
	ib_net32_t rn_subgroup_priority_flags[IB_RN_GEN_BY_SUB_GROUP_PRIORITY_BLOCK_SIZE];
	uint8_t rn_xmit_port_mask[IB_RN_XMIT_PORT_MASK_BLOCK_SIZE * 2];
} osm_ar_tables_t;


typedef struct osm_advanced_routing_data {
	uint8_t status;
	ib_ar_info_t ar_info;
	ib_ar_info_t req_ar_info;
	uint16_t num_groups;
	uint8_t num_tables;
	uint8_t num_group_subgroups;
	uint16_t num_lids;
	uint16_t num_strings;
	uint16_t num_directions;
	uint16_t group_top;
	osm_ar_tables_t subn_tables;
	osm_ar_tables_t calc_tables;
	cl_qlist_t cached_capabilities_list;
	uint16_t *ar_group_copy_from_table;
} osm_advanced_routing_data_t;
/*
* FIELDS
*/

/* advanced routing data initialization */

void osm_ar_data_init(osm_advanced_routing_data_t *p_ar_data);

int osm_ar_prepare_tables(osm_subn_t *p_subn,
			  osm_advanced_routing_data_t *p_ar_data,
			  uint16_t num_lids);

void osm_ar_data_destroy(osm_advanced_routing_data_t *p_ar_data);


/* advanced routing data configuration and retrieval */

void osm_ar_set_required_ar_info(osm_advanced_routing_data_t *p_ar_data,
				 const ib_ar_info_t *p_ar_info);

int osm_ar_set_required_group_top(osm_advanced_routing_data_t *p_ar_data,
				  uint16_t group_top);

int osm_ar_set_required_ar_mode(osm_advanced_routing_data_t *p_ar_data,
				boolean_t enable_ar, boolean_t enable_fr);

int osm_ar_set_required_num_subgroups(osm_advanced_routing_data_t *p_ar_data,
				      uint8_t num_subgroups);

int osm_ar_set_required_enabled_sl_mask(osm_advanced_routing_data_t *p_ar_data,
					uint16_t sl_mask);

int osm_ar_set_required_enabled_transport_mask(osm_advanced_routing_data_t *p_ar_data,
					       uint8_t enabled_transport_mask);


osm_ar_subgroup_t * osm_ar_subgroup_get(osm_advanced_routing_data_t *p_ar_data,
					uint16_t group_id, uint8_t subgroup_id);

void osm_ar_subgroup_add_port(osm_ar_subgroup_t *p_subgroup, uint8_t port);

void osm_ar_subgroup_clear(osm_ar_subgroup_t *p_subgroup);


void osm_ar_groups_clear_group(osm_advanced_routing_data_t *p_ar_data,
			       uint16_t group_id);

void osm_ar_groups_clear_tbl(osm_advanced_routing_data_t *p_ar_data);

void osm_ar_groups_clear_all(osm_advanced_routing_data_t *p_ar_data);

void osm_ar_groups_copy_group(osm_advanced_routing_data_t *p_ar_data,
			      uint16_t src_group_id, uint16_t dst_group_id,
			      boolean_t copy_direction);

void osm_ar_lft_set(osm_advanced_routing_data_t *p_ar_data, uint16_t lid,
		    uint8_t port, uint8_t state, uint16_t group_id);

void osm_ar_lft_copy(osm_advanced_routing_data_t *p_ar_data,
		     uint16_t copy_to_lid, uint16_t copy_from_lid);

void osm_ar_set_subgroup_direction(osm_advanced_routing_data_t *p_ar_data,
				   uint16_t group_id, uint8_t subgroup_id,
				   uint8_t direction);

uint8_t osm_ar_subgroup_direction_get(osm_advanced_routing_data_t *p_ar_data,
				      uint16_t group_id, uint8_t subgroup_id);

void osm_ar_subgroup_pri_rn_flags_set(osm_advanced_routing_data_t *p_ar_data,
				      uint8_t subgroup_priority,
				      uint8_t rn_flags);
void osm_ar_rn_direction_string_set(osm_advanced_routing_data_t *p_ar_data,
				    uint8_t direction, uint16_t string);
void osm_ar_rn_string_handling_set(osm_advanced_routing_data_t *p_ar_data,
				   uint16_t string, uint8_t decision,
				   uint16_t new_string);

void osm_ar_rn_port_xmit_mask_add_port(osm_advanced_routing_data_t *p_ar_data,
				       uint8_t port, uint8_t mask);

void osm_ar_rn_port_xmit_mask_clear(osm_advanced_routing_data_t *p_ar_data);

ib_api_status_t osm_ar_get_ar_info(struct osm_sm *sm, struct osm_switch *p_sw);
ib_api_status_t osm_ar_query_ar_info(struct osm_sm *sm, struct osm_switch *p_sw,
				     ib_ar_info_t *p_ar_info);
ib_api_status_t osm_ar_set_ar_info(struct osm_sm *sm, struct osm_switch *p_sw,
				   ib_ar_info_t *p_ar_info);

void osm_ar_capabilities_clear_all(osm_advanced_routing_data_t *p_ar_data);

const ib_ar_info_t *
osm_ar_capabilities_search(osm_advanced_routing_data_t *p_ar_data,
			  const ib_ar_info_t *p_ar_info);
int osm_ar_capabilities_update(osm_advanced_routing_data_t *p_ar_data,
			      const ib_ar_info_t *p_ar_info);


/* subnet configuration */

int osm_ar_set_subn_ar_tables(struct osm_sm *sm);

/* handle received data */

int osm_ar_groups_set_block(osm_advanced_routing_data_t *p_ar_data,
			    uint16_t block_id, ib_ar_group_table_t *p_block);

int osm_ar_lft_set_block(osm_advanced_routing_data_t *p_ar_data,
			 uint16_t block_id, ib_ar_lft_t *p_block);

int osm_ar_rn_gen_string_set_block(osm_advanced_routing_data_t *p_ar_data,
				   int16_t block_id,
				   ib_rn_gen_string_table_t *p_block);

void osm_ar_rn_string_handling_clear(osm_advanced_routing_data_t *p_ar_data);

int osm_ar_rn_rcv_string_set_block(osm_advanced_routing_data_t *p_ar_data,
				   int16_t block_id,
				   ib_rn_rcv_string_table_t *p_block);

int osm_ar_rn_sub_group_direction_set_block(osm_advanced_routing_data_t *p_ar_data,
					    int16_t block_id,
					    ib_rn_sub_group_direction_table_t *p_block);

int osm_ar_rn_xmit_port_mask_set_block(osm_advanced_routing_data_t *p_ar_data,
				       int16_t block_id,
				       ib_rn_xmit_port_mask_t *p_block);

int osm_ar_rn_subgroup_priority_flags_set_block(osm_advanced_routing_data_t *p_ar_data,
						ib_rn_gen_by_sub_group_priority_t *p_block);


/* compare calculated AR LFT data to assigned AR LFT data */
int osm_ar_cmp_ar_lft(osm_advanced_routing_data_t *p_ar_data);
int osm_ar_reallocate_lft_table(ib_ar_lft_entry_t **pp_ar_lft,
				uint16_t prev_num_lids,
				uint16_t num_lids, boolean_t clear_all);
END_C_DECLS
#endif				/* _OSM_ADAPTIVE_ROUTING_H_ */
